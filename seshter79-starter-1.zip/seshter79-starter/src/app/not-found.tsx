import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center px-4 text-center">
      <h1 className="text-6xl font-bold text-surface-600">404</h1>
      <p className="mt-4 text-xl font-medium">Page not found</p>
      <p className="mt-2 text-surface-400">
        The page you are looking for does not exist or was removed.
      </p>
      <Link
        href="/"
        className="mt-8 rounded-full bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500"
      >
        Back to Home
      </Link>
    </div>
  );
}
