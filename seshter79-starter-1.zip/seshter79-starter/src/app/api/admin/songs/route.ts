import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions, canManageContent } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/utils";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || !canManageContent(session.user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const songs = await prisma.song.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      artist: { select: { id: true, name: true } },
      album: { select: { id: true, title: true } },
      genre: { select: { id: true, name: true } },
    },
    take: 100,
  });

  return NextResponse.json(songs);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || !canManageContent(session.user.role)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const formData = await req.formData();

    const title = String(formData.get("title") || "").trim();
    const artistName = String(formData.get("artistName") || "").trim();
    const genreId = String(formData.get("genreId") || "") || null;
    const lyrics = String(formData.get("lyrics") || "") || null;
    const description = String(formData.get("description") || "") || null;
    const allowDownload = formData.get("allowDownload") === "true";
    const isFeatured = formData.get("isFeatured") === "true";
    const isTrending = formData.get("isTrending") === "true";
    const status = (formData.get("status") as string) || "PUBLISHED";
    const duration = parseInt(String(formData.get("duration") || "0"), 10) || 0;

    if (!title || !artistName) {
      return NextResponse.json(
        { error: "Title and artist are required" },
        { status: 400 }
      );
    }

    const audioFile = formData.get("audio") as File | null;
    if (!audioFile || audioFile.size === 0) {
      return NextResponse.json(
        { error: "Audio file is required" },
        { status: 400 }
      );
    }

    // Validate audio type
    const allowedAudio = [
      "audio/mpeg",
      "audio/mp3",
      "audio/wav",
      "audio/x-wav",
      "audio/mp4",
      "audio/m4a",
      "audio/aac",
      "audio/ogg",
    ];
    if (
      !allowedAudio.includes(audioFile.type) &&
      !audioFile.name.match(/\.(mp3|wav|m4a|aac|ogg)$/i)
    ) {
      return NextResponse.json(
        { error: "Invalid audio format. Use MP3, WAV, M4A, AAC or OGG." },
        { status: 400 }
      );
    }

    if (audioFile.size > 50 * 1024 * 1024) {
      return NextResponse.json(
        { error: "Audio file too large (max 50MB)" },
        { status: 400 }
      );
    }

    // Ensure artist exists
    let artist = await prisma.artist.findFirst({
      where: { name: { equals: artistName, mode: "insensitive" } },
    });
    if (!artist) {
      const artistSlug = slugify(artistName);
      artist = await prisma.artist.create({
        data: {
          name: artistName,
          slug: artistSlug + "-" + randomUUID().slice(0, 6),
        },
      });
    }

    // Save audio
    const audioExt = path.extname(audioFile.name) || ".mp3";
    const audioId = randomUUID();
    const audioFileName = `${audioId}${audioExt}`;
    const audioDir = path.join(process.cwd(), "public", "uploads", "audio");
    await mkdir(audioDir, { recursive: true });
    const audioBuffer = Buffer.from(await audioFile.arrayBuffer());
    await writeFile(path.join(audioDir, audioFileName), audioBuffer);
    const audioUrl = `/uploads/audio/${audioFileName}`;

    // Optional cover
    let coverUrl: string | null = null;
    const coverFile = formData.get("cover") as File | null;
    if (coverFile && coverFile.size > 0) {
      const allowedImg = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
      if (
        allowedImg.includes(coverFile.type) ||
        coverFile.name.match(/\.(jpg|jpeg|png|webp)$/i)
      ) {
        const coverExt = path.extname(coverFile.name) || ".jpg";
        const coverFileName = `${randomUUID()}${coverExt}`;
        const coverDir = path.join(process.cwd(), "public", "uploads", "covers");
        await mkdir(coverDir, { recursive: true });
        const coverBuffer = Buffer.from(await coverFile.arrayBuffer());
        await writeFile(path.join(coverDir, coverFileName), coverBuffer);
        coverUrl = `/uploads/covers/${coverFileName}`;
      }
    }

    const baseSlug = slugify(`${artistName}-${title}`);
    let slug = baseSlug;
    let exists = await prisma.song.findUnique({ where: { slug } });
    if (exists) slug = `${baseSlug}-${randomUUID().slice(0, 6)}`;

    const song = await prisma.song.create({
      data: {
        title,
        slug,
        artistId: artist.id,
        genreId: genreId || undefined,
        coverImage: coverUrl,
        audioUrl,
        downloadUrl: allowDownload ? audioUrl : null,
        duration,
        lyrics,
        description,
        status: status === "DRAFT" ? "DRAFT" : "PUBLISHED",
        isFeatured,
        isTrending,
        allowDownload,
        publishedAt: status === "DRAFT" ? null : new Date(),
      },
      include: {
        artist: true,
        genre: true,
      },
    });

    return NextResponse.json(song, { status: 201 });
  } catch (error) {
    console.error("Upload error:", error);
    return NextResponse.json(
      { error: "Failed to upload song" },
      { status: 500 }
    );
  }
}
