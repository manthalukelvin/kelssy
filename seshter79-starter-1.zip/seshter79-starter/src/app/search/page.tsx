import { prisma } from "@/lib/prisma";
import { SongCard } from "@/components/music/SongCard";
import type { PlayerTrack } from "@/store/playerStore";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const metadata = { title: "Search" };

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q: raw } = await searchParams;
  const q = raw?.trim() || "";

  let songs: any[] = [];
  let artists: any[] = [];

  if (q.length >= 1) {
    try {
      [songs, artists] = await Promise.all([
        prisma.song.findMany({
          where: {
            status: "PUBLISHED",
            OR: [
              { title: { contains: q, mode: "insensitive" } },
              { artist: { name: { contains: q, mode: "insensitive" } } },
              { tags: { has: q.toLowerCase() } },
            ],
          },
          include: { artist: { select: { name: true } } },
          take: 30,
        }),
        prisma.artist.findMany({
          where: { name: { contains: q, mode: "insensitive" } },
          take: 10,
        }),
      ]);
    } catch {}
  }

  const queue: PlayerTrack[] = songs.map((s) => ({
    id: s.id,
    title: s.title,
    slug: s.slug,
    artistName: s.artist.name,
    coverImage: s.coverImage,
    audioUrl: s.audioUrl,
    duration: s.duration,
    allowDownload: s.allowDownload,
  }));

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="mb-6 text-3xl font-bold">Search</h1>

      <form className="mb-10">
        <input
          name="q"
          defaultValue={q}
          placeholder="Search songs, artists..."
          autoFocus
          className="w-full max-w-xl rounded-xl border border-surface-700 bg-surface-900 px-5 py-3.5 text-lg outline-none focus:border-brand-500"
        />
      </form>

      {!q && (
        <p className="text-surface-500">Type something to search.</p>
      )}

      {q && songs.length === 0 && artists.length === 0 && (
        <p className="text-surface-500">
          No results for &ldquo;{q}&rdquo;.
        </p>
      )}

      {artists.length > 0 && (
        <section className="mb-10">
          <h2 className="mb-4 text-lg font-semibold">Artists</h2>
          <div className="flex flex-wrap gap-3">
            {artists.map((a) => (
              <Link
                key={a.id}
                href={`/artist/${a.slug}`}
                className="rounded-full border border-surface-700 px-4 py-2 text-sm hover:bg-surface-800"
              >
                {a.name}
              </Link>
            ))}
          </div>
        </section>
      )}

      {songs.length > 0 && (
        <section>
          <h2 className="mb-4 text-lg font-semibold">Songs</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {songs.map((song) => (
              <SongCard key={song.id} song={song} queue={queue} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
