import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { PlayButton } from "@/components/music/PlayButton";
import { formatDuration, formatPlayCount } from "@/lib/utils";
import Link from "next/link";
import { Download } from "lucide-react";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  try {
    const song = await prisma.song.findUnique({
      where: { slug },
      include: { artist: true },
    });
    if (!song) return { title: "Song not found" };
    return {
      title: `${song.title} — ${song.artist.name}`,
      description: song.description || `Listen to ${song.title} by ${song.artist.name} on Seshter 79`,
      openGraph: {
        title: song.title,
        description: `By ${song.artist.name}`,
        images: song.coverImage ? [song.coverImage] : [],
      },
    };
  } catch {
    return { title: "Song" };
  }
}

export default async function SongPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  let song: any = null;
  try {
    song = await prisma.song.findUnique({
      where: { slug },
      include: {
        artist: true,
        genre: true,
        album: true,
      },
    });
  } catch {}

  if (!song || song.status !== "PUBLISHED") notFound();

  // Increment play count lightly (best-effort)
  prisma.song
    .update({
      where: { id: song.id },
      data: { playCount: { increment: 1 } },
    })
    .catch(() => {});

  const track = {
    id: song.id,
    title: song.title,
    slug: song.slug,
    artistName: song.artist.name,
    coverImage: song.coverImage,
    audioUrl: song.audioUrl,
    duration: song.duration,
    allowDownload: song.allowDownload,
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
      <div className="flex flex-col gap-8 sm:flex-row">
        <div className="mx-auto h-64 w-64 shrink-0 overflow-hidden rounded-2xl bg-surface-800 shadow-xl sm:mx-0 sm:h-72 sm:w-72">
          {song.coverImage ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={song.coverImage}
              alt={song.title}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-6xl font-bold text-surface-600">
              {song.title[0]}
            </div>
          )}
        </div>

        <div className="flex flex-1 flex-col justify-center">
          <p className="text-sm font-medium uppercase tracking-wider text-brand-400">
            Song
          </p>
          <h1 className="mt-1 text-3xl font-bold sm:text-4xl">{song.title}</h1>
          <Link
            href={`/artist/${song.artist.slug}`}
            className="mt-2 text-lg text-surface-300 hover:underline"
          >
            {song.artist.name}
          </Link>

          <div className="mt-4 flex flex-wrap gap-3 text-sm text-surface-400">
            {song.genre && (
              <Link href={`/genre/${song.genre.slug}`} className="hover:text-white">
                {song.genre.name}
              </Link>
            )}
            <span>{formatDuration(song.duration)}</span>
            <span>{formatPlayCount(song.playCount)} plays</span>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <PlayButton track={track} />
            {song.allowDownload && (
              <a
                href={song.audioUrl}
                download
                className="inline-flex items-center gap-2 rounded-full border border-surface-600 px-6 py-3 text-sm font-semibold hover:bg-surface-800"
              >
                <Download className="h-4 w-4" />
                Download
              </a>
            )}
          </div>
        </div>
      </div>

      {song.lyrics && (
        <div className="mt-12">
          <h2 className="mb-4 text-xl font-bold">Lyrics</h2>
          <pre className="whitespace-pre-wrap rounded-xl bg-surface-900 p-6 text-sm leading-relaxed text-surface-300">
            {song.lyrics}
          </pre>
        </div>
      )}

      {song.description && (
        <div className="mt-8">
          <h2 className="mb-2 text-lg font-semibold">About</h2>
          <p className="text-surface-400">{song.description}</p>
        </div>
      )}
    </div>
  );
}
