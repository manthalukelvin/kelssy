import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/Providers";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { SiteFooter } from "@/components/layout/SiteFooter";
import { MobileNav } from "@/components/layout/MobileNav";
import { MusicPlayer } from "@/components/player/MusicPlayer";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-geist-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Seshter 79 — Stream & Download Music",
    template: "%s | Seshter 79",
  },
  description:
    "Discover, stream and download the best music on Seshter 79. Afrobeats, Hip-Hop, Gospel, Amapiano and more.",
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_APP_URL || "https://music.myjournalplus.com"
  ),
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "Seshter 79",
  },
  twitter: {
    card: "summary_large_image",
  },
  robots: {
    index: true,
    follow: true,
  },
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#020617",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} font-sans antialiased`}>
        <Providers>
          <div className="flex min-h-screen flex-col">
            <SiteHeader />
            <main className="flex-1 pb-28 md:pb-24">{children}</main>
            <SiteFooter />
            <MobileNav />
            <MusicPlayer />
          </div>
        </Providers>
      </body>
    </html>
  );
}
