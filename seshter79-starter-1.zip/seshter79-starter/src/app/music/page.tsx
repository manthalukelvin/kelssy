import { prisma } from "@/lib/prisma";
import { SongCard } from "@/components/music/SongCard";
import type { PlayerTrack } from "@/store/playerStore";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const metadata = { title: "Music" };

export default async function MusicPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; genre?: string }>;
}) {
  const params = await searchParams;
  const q = params.q?.trim();

  let songs: any[] = [];
  try {
    songs = await prisma.song.findMany({
      where: {
        status: "PUBLISHED",
        ...(q
          ? {
              OR: [
                { title: { contains: q, mode: "insensitive" } },
                { artist: { name: { contains: q, mode: "insensitive" } } },
              ],
            }
          : {}),
      },
      include: { artist: { select: { name: true } } },
      orderBy: { publishedAt: "desc" },
      take: 60,
    });
  } catch {}

  const queue: PlayerTrack[] = songs.map((s) => ({
    id: s.id,
    title: s.title,
    slug: s.slug,
    artistName: s.artist.name,
    coverImage: s.coverImage,
    audioUrl: s.audioUrl,
    duration: s.duration,
    allowDownload: s.allowDownload,
  }));

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-3xl font-bold">Music</h1>
        <form action="/search" className="w-full sm:w-72">
          <input
            name="q"
            defaultValue={q}
            placeholder="Search songs..."
            className="w-full rounded-xl border border-surface-700 bg-surface-900 px-4 py-2.5 text-sm outline-none focus:border-brand-500"
          />
        </form>
      </div>

      {songs.length === 0 ? (
        <div className="rounded-xl border border-dashed border-surface-700 p-12 text-center text-surface-400">
          <p>No published songs found.</p>
          <Link href="/admin/songs/upload" className="mt-2 inline-block text-brand-400 hover:underline">
            Upload songs from admin →
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {songs.map((song) => (
            <SongCard key={song.id} song={song} queue={queue} />
          ))}
        </div>
      )}
    </div>
  );
}
