import { prisma } from "@/lib/prisma";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const metadata = { title: "Albums" };

export default async function AlbumsPage() {
  let albums: any[] = [];
  try {
    albums = await prisma.album.findMany({
      where: { status: "PUBLISHED" },
      include: { artist: { select: { name: true } } },
      orderBy: { releaseDate: "desc" },
      take: 50,
    });
  } catch {}

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="mb-8 text-3xl font-bold">Albums</h1>
      {albums.length === 0 ? (
        <p className="text-surface-500">
          No albums yet. Albums can be created when you expand the admin later.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {albums.map((a) => (
            <Link
              key={a.id}
              href={`/album/${a.slug}`}
              className="rounded-xl bg-surface-900 p-3 hover:bg-surface-800"
            >
              <div className="mb-3 aspect-square overflow-hidden rounded-lg bg-surface-800">
                {a.coverImage && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={a.coverImage} alt="" className="h-full w-full object-cover" />
                )}
              </div>
              <p className="font-medium truncate">{a.title}</p>
              <p className="text-sm text-surface-400 truncate">{a.artist.name}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
