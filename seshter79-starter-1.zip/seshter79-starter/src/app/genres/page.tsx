import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";
export const metadata = { title: "Genres" };

export default async function GenresPage() {
  let genres: any[] = [];
  try {
    genres = await prisma.genre.findMany({ orderBy: { sortOrder: "asc" } });
  } catch {}

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="mb-8 text-3xl font-bold">Genres</h1>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
        {genres.map((g) => (
          <Link
            key={g.id}
            href={`/genre/${g.slug}`}
            className="flex h-28 items-end rounded-xl bg-gradient-to-br from-surface-800 to-surface-900 p-5 text-lg font-semibold hover:from-brand-900/50 transition"
          >
            {g.name}
          </Link>
        ))}
        {genres.length === 0 && (
          <p className="col-span-full text-surface-500">
            No genres yet. Run the seed script.
          </p>
        )}
      </div>
    </div>
  );
}
