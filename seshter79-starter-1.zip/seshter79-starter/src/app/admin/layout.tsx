import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions, isAdmin } from "@/lib/auth";
import Link from "next/link";
import {
  LayoutDashboard,
  Music,
  Users,
  Disc3,
  Mic2,
  Tags,
  Newspaper,
  Settings,
  BarChart3,
  LogOut,
} from "lucide-react";

const adminNav = [
  { href: "/admin", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/admin/songs", icon: Music, label: "Songs" },
  { href: "/admin/artists", icon: Mic2, label: "Artists" },
  { href: "/admin/albums", icon: Disc3, label: "Albums" },
  { href: "/admin/genres", icon: Tags, label: "Genres" },
  { href: "/admin/news", icon: Newspaper, label: "News" },
  { href: "/admin/users", icon: Users, label: "Users" },
  { href: "/admin/analytics", icon: BarChart3, label: "Analytics" },
  { href: "/admin/settings", icon: Settings, label: "Settings" },
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);

  if (!session || !isAdmin(session.user.role)) {
    redirect("/login?callbackUrl=/admin");
  }

  return (
    <div className="flex min-h-screen bg-surface-950">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-surface-800 bg-surface-900 md:flex">
        <div className="flex h-16 items-center gap-2 border-b border-surface-800 px-5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-accent-purple text-xs font-bold text-white">
            S79
          </div>
          <span className="font-bold text-sm">Admin</span>
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto p-3">
          {adminNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-surface-400 hover:bg-surface-800 hover:text-white transition"
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-surface-800 p-3">
          <Link
            href="/"
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-surface-400 hover:bg-surface-800 hover:text-white"
          >
            <LogOut className="h-4 w-4" />
            Back to site
          </Link>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 md:pl-60">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-surface-800 bg-surface-950/80 px-6 backdrop-blur">
          <h1 className="text-lg font-semibold">Seshter 79 Admin</h1>
          <div className="text-sm text-surface-400">
            {session.user.email} · {session.user.role}
          </div>
        </header>
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}
