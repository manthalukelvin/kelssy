import { prisma } from "@/lib/prisma";
import { Music, Users, Disc3, Mic2, Play, Download, Heart } from "lucide-react";

async function getStats() {
  const [
    songs,
    artists,
    albums,
    users,
    plays,
    downloads,
    likes,
  ] = await Promise.all([
    prisma.song.count(),
    prisma.artist.count(),
    prisma.album.count(),
    prisma.user.count(),
    prisma.play.count(),
    prisma.download.count(),
    prisma.favorite.count(),
  ]);

  return { songs, artists, albums, users, plays, downloads, likes };
}

export default async function AdminDashboard() {
  let stats = {
    songs: 0,
    artists: 0,
    albums: 0,
    users: 0,
    plays: 0,
    downloads: 0,
    likes: 0,
  };

  try {
    stats = await getStats();
  } catch {
    // DB not ready yet – show zeros
  }

  const cards = [
    { label: "Songs", value: stats.songs, icon: Music, color: "text-brand-400" },
    { label: "Artists", value: stats.artists, icon: Mic2, color: "text-accent-purple" },
    { label: "Albums", value: stats.albums, icon: Disc3, color: "text-accent-cyan" },
    { label: "Users", value: stats.users, icon: Users, color: "text-accent-emerald" },
    { label: "Total Plays", value: stats.plays, icon: Play, color: "text-brand-300" },
    { label: "Downloads", value: stats.downloads, icon: Download, color: "text-accent-pink" },
    { label: "Likes", value: stats.likes, icon: Heart, color: "text-red-400" },
  ];

  return (
    <div>
      <h2 className="mb-6 text-2xl font-bold">Dashboard</h2>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {cards.map((card) => (
          <div
            key={card.label}
            className="rounded-xl border border-surface-800 bg-surface-900 p-5"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-surface-400">{card.label}</span>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </div>
            <p className="mt-2 text-3xl font-bold">{card.value.toLocaleString()}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 rounded-xl border border-surface-800 bg-surface-900 p-6">
        <h3 className="mb-2 font-semibold">Getting started</h3>
        <ol className="list-decimal space-y-2 pl-5 text-sm text-surface-400">
          <li>Configure your database and run <code className="text-brand-400">npx prisma db push</code></li>
          <li>Create a Super Admin with the seed script</li>
          <li>Go to Songs → Upload your first track</li>
          <li>Add artists, albums and genres</li>
          <li>Publish content and it will appear on the public site</li>
        </ol>
      </div>
    </div>
  );
}
