import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { Plus, Music } from "lucide-react";
import { formatDuration, formatPlayCount } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminSongsPage() {
  let songs: any[] = [];
  try {
    songs = await prisma.song.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        artist: { select: { name: true } },
        genre: { select: { name: true } },
      },
      take: 100,
    });
  } catch {
    // DB may still be empty
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-2xl font-bold">Songs</h2>
        <Link
          href="/admin/songs/upload"
          className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-500"
        >
          <Plus className="h-4 w-4" />
          Upload Song
        </Link>
      </div>

      {songs.length === 0 ? (
        <div className="rounded-xl border border-dashed border-surface-700 bg-surface-900/50 p-12 text-center">
          <Music className="mx-auto h-12 w-12 text-surface-600" />
          <p className="mt-4 text-surface-400">No songs yet</p>
          <Link
            href="/admin/songs/upload"
            className="mt-4 inline-flex text-brand-400 hover:underline"
          >
            Upload your first song →
          </Link>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-surface-800">
          <table className="w-full text-left text-sm">
            <thead className="bg-surface-900 text-surface-400">
              <tr>
                <th className="px-4 py-3 font-medium">Song</th>
                <th className="px-4 py-3 font-medium">Artist</th>
                <th className="px-4 py-3 font-medium">Genre</th>
                <th className="px-4 py-3 font-medium">Duration</th>
                <th className="px-4 py-3 font-medium">Plays</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-800">
              {songs.map((song) => (
                <tr key={song.id} className="hover:bg-surface-900/50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 overflow-hidden rounded bg-surface-800">
                        {song.coverImage ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={song.coverImage}
                            alt=""
                            className="h-full w-full object-cover"
                          />
                        ) : null}
                      </div>
                      <span className="font-medium">{song.title}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-surface-400">
                    {song.artist?.name}
                  </td>
                  <td className="px-4 py-3 text-surface-400">
                    {song.genre?.name || "—"}
                  </td>
                  <td className="px-4 py-3 text-surface-400">
                    {formatDuration(song.duration)}
                  </td>
                  <td className="px-4 py-3 text-surface-400">
                    {formatPlayCount(song.playCount)}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${
                        song.status === "PUBLISHED"
                          ? "bg-emerald-500/20 text-emerald-400"
                          : "bg-surface-700 text-surface-400"
                      }`}
                    >
                      {song.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
