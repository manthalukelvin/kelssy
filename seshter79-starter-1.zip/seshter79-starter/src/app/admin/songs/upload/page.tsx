"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { Upload, Loader2 } from "lucide-react";

type Genre = { id: string; name: string };

export default function UploadSongPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [audioName, setAudioName] = useState("");
  const [coverName, setCoverName] = useState("");

  useEffect(() => {
    fetch("/api/genres")
      .then((r) => r.json())
      .then((d) => setGenres(Array.isArray(d) ? d : []))
      .catch(() => {});
  }, []);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    const audio = formData.get("audio") as File;
    if (!audio || audio.size === 0) {
      toast.error("Please select an audio file");
      return;
    }

    setLoading(true);
    try {
      // Try to get duration from browser
      const duration = await getAudioDuration(audio);
      formData.set("duration", String(Math.round(duration)));

      const res = await fetch("/api/admin/songs", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Upload failed");
        return;
      }
      toast.success("Song uploaded successfully!");
      router.push("/admin/songs");
      router.refresh();
    } catch {
      toast.error("Upload failed");
    } finally {
      setLoading(false);
    }
  }

  function getAudioDuration(file: File): Promise<number> {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(file);
      const audio = new Audio();
      audio.addEventListener("loadedmetadata", () => {
        resolve(audio.duration || 0);
        URL.revokeObjectURL(url);
      });
      audio.addEventListener("error", () => {
        resolve(0);
        URL.revokeObjectURL(url);
      });
      audio.src = url;
    });
  }

  return (
    <div className="max-w-2xl">
      <h2 className="mb-6 text-2xl font-bold">Upload Song</h2>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="mb-1.5 block text-sm font-medium">Title *</label>
          <input
            name="title"
            required
            className="w-full rounded-xl border border-surface-700 bg-surface-950 px-4 py-3 text-sm outline-none focus:border-brand-500"
            placeholder="Song title"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium">Artist *</label>
          <input
            name="artistName"
            required
            className="w-full rounded-xl border border-surface-700 bg-surface-950 px-4 py-3 text-sm outline-none focus:border-brand-500"
            placeholder="Artist name (created automatically if new)"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium">Genre</label>
          <select
            name="genreId"
            className="w-full rounded-xl border border-surface-700 bg-surface-950 px-4 py-3 text-sm outline-none focus:border-brand-500"
          >
            <option value="">— Select genre —</option>
            {genres.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium">Audio file *</label>
          <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-surface-700 bg-surface-950 px-4 py-8 hover:border-brand-500 transition">
            <Upload className="h-8 w-8 text-surface-500 mb-2" />
            <span className="text-sm text-surface-400">
              {audioName || "Click to select MP3 / M4A / WAV (max 50MB)"}
            </span>
            <input
              type="file"
              name="audio"
              accept="audio/*,.mp3,.m4a,.wav,.aac,.ogg"
              required
              className="hidden"
              onChange={(e) =>
                setAudioName(e.target.files?.[0]?.name || "")
              }
            />
          </label>
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium">Cover image</label>
          <label className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-surface-700 bg-surface-950 px-4 py-6 hover:border-brand-500 transition">
            <span className="text-sm text-surface-400">
              {coverName || "Optional JPG / PNG / WebP"}
            </span>
            <input
              type="file"
              name="cover"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={(e) =>
                setCoverName(e.target.files?.[0]?.name || "")
              }
            />
          </label>
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium">Lyrics</label>
          <textarea
            name="lyrics"
            rows={4}
            className="w-full rounded-xl border border-surface-700 bg-surface-950 px-4 py-3 text-sm outline-none focus:border-brand-500"
            placeholder="Optional lyrics"
          />
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium">Description</label>
          <textarea
            name="description"
            rows={2}
            className="w-full rounded-xl border border-surface-700 bg-surface-950 px-4 py-3 text-sm outline-none focus:border-brand-500"
            placeholder="Optional description"
          />
        </div>

        <div className="flex flex-wrap gap-6">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="allowDownload" value="true" className="rounded" />
            Allow download
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="isFeatured" value="true" className="rounded" />
            Featured
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="isTrending" value="true" className="rounded" />
            Trending
          </label>
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium">Status</label>
          <select
            name="status"
            defaultValue="PUBLISHED"
            className="w-full rounded-xl border border-surface-700 bg-surface-950 px-4 py-3 text-sm outline-none focus:border-brand-500"
          >
            <option value="PUBLISHED">Published (visible on site)</option>
            <option value="DRAFT">Draft (hidden)</option>
          </select>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand-600 py-3.5 text-sm font-semibold text-white hover:bg-brand-500 disabled:opacity-50"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Uploading...
            </>
          ) : (
            <>
              <Upload className="h-4 w-4" />
              Upload & Publish
            </>
          )}
        </button>
      </form>
    </div>
  );
}
