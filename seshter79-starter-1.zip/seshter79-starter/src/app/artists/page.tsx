import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";
export const metadata = { title: "Artists" };

export default async function ArtistsPage() {
  let artists: any[] = [];
  try {
    artists = await prisma.artist.findMany({
      orderBy: { name: "asc" },
      take: 100,
    });
  } catch {}

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="mb-8 text-3xl font-bold">Artists</h1>
      {artists.length === 0 ? (
        <p className="text-surface-500">
          No artists yet. They appear automatically when you upload songs.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {artists.map((a) => (
            <Link
              key={a.id}
              href={`/artist/${a.slug}`}
              className="group rounded-xl bg-surface-900 p-4 text-center hover:bg-surface-800 transition"
            >
              <div className="mx-auto mb-3 flex h-24 w-24 items-center justify-center overflow-hidden rounded-full bg-surface-800 text-3xl font-bold text-surface-500">
                {a.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={a.image} alt="" className="h-full w-full object-cover" />
                ) : (
                  a.name[0]
                )}
              </div>
              <p className="font-medium group-hover:underline">{a.name}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
