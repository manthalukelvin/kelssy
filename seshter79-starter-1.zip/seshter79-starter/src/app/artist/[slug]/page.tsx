import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { SongCard } from "@/components/music/SongCard";
import type { PlayerTrack } from "@/store/playerStore";

export const dynamic = "force-dynamic";

export default async function ArtistPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  let artist: any = null;
  let songs: any[] = [];
  try {
    artist = await prisma.artist.findUnique({ where: { slug } });
    if (artist) {
      songs = await prisma.song.findMany({
        where: { status: "PUBLISHED", artistId: artist.id },
        include: { artist: { select: { name: true } } },
        orderBy: { playCount: "desc" },
      });
    }
  } catch {}

  if (!artist) notFound();

  const queue: PlayerTrack[] = songs.map((s) => ({
    id: s.id,
    title: s.title,
    slug: s.slug,
    artistName: s.artist.name,
    coverImage: s.coverImage,
    audioUrl: s.audioUrl,
    duration: s.duration,
    allowDownload: s.allowDownload,
  }));

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-10 flex items-center gap-6">
        <div className="flex h-28 w-28 items-center justify-center overflow-hidden rounded-full bg-surface-800 text-4xl font-bold text-surface-500">
          {artist.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={artist.image} alt="" className="h-full w-full object-cover" />
          ) : (
            artist.name[0]
          )}
        </div>
        <div>
          <p className="text-sm uppercase tracking-wider text-brand-400">Artist</p>
          <h1 className="text-3xl font-bold sm:text-4xl">{artist.name}</h1>
          {artist.bio && (
            <p className="mt-2 max-w-xl text-surface-400">{artist.bio}</p>
          )}
        </div>
      </div>

      <h2 className="mb-4 text-xl font-bold">Songs</h2>
      {songs.length === 0 ? (
        <p className="text-surface-500">No published songs yet.</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {songs.map((song) => (
            <SongCard key={song.id} song={song} queue={queue} />
          ))}
        </div>
      )}
    </div>
  );
}
