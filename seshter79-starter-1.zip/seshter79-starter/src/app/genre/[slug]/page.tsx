import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { SongCard } from "@/components/music/SongCard";
import type { PlayerTrack } from "@/store/playerStore";

export const dynamic = "force-dynamic";

export default async function GenrePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  let genre: any = null;
  let songs: any[] = [];
  try {
    genre = await prisma.genre.findUnique({ where: { slug } });
    if (genre) {
      songs = await prisma.song.findMany({
        where: { status: "PUBLISHED", genreId: genre.id },
        include: { artist: { select: { name: true } } },
        orderBy: { playCount: "desc" },
        take: 50,
      });
    }
  } catch {}

  if (!genre) notFound();

  const queue: PlayerTrack[] = songs.map((s) => ({
    id: s.id,
    title: s.title,
    slug: s.slug,
    artistName: s.artist.name,
    coverImage: s.coverImage,
    audioUrl: s.audioUrl,
    duration: s.duration,
    allowDownload: s.allowDownload,
  }));

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="mb-2 text-3xl font-bold">{genre.name}</h1>
      {genre.description && (
        <p className="mb-8 text-surface-400">{genre.description}</p>
      )}
      {songs.length === 0 ? (
        <p className="text-surface-500">No songs in this genre yet.</p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {songs.map((song) => (
            <SongCard key={song.id} song={song} queue={queue} />
          ))}
        </div>
      )}
    </div>
  );
}
