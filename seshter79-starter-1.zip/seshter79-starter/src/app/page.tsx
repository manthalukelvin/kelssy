import Link from "next/link";
import { Play, TrendingUp, Sparkles, Music2 } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { SongCard, SongRow } from "@/components/music/SongCard";
import type { PlayerTrack } from "@/store/playerStore";

export const dynamic = "force-dynamic";

async function getHomeData() {
  try {
    const [featured, trending, latest, genres] = await Promise.all([
      prisma.song.findMany({
        where: { status: "PUBLISHED", isFeatured: true },
        include: { artist: { select: { name: true } } },
        take: 10,
        orderBy: { publishedAt: "desc" },
      }),
      prisma.song.findMany({
        where: { status: "PUBLISHED", isTrending: true },
        include: { artist: { select: { name: true } } },
        take: 8,
        orderBy: { playCount: "desc" },
      }),
      prisma.song.findMany({
        where: { status: "PUBLISHED" },
        include: { artist: { select: { name: true } } },
        take: 10,
        orderBy: { publishedAt: "desc" },
      }),
      prisma.genre.findMany({
        orderBy: { sortOrder: "asc" },
        take: 8,
      }),
    ]);

    const featuredFinal = featured.length ? featured : latest.slice(0, 5);
    const trendingFinal = trending.length ? trending : latest.slice(0, 6);

    return { featured: featuredFinal, trending: trendingFinal, latest, genres };
  } catch {
    return { featured: [], trending: [], latest: [], genres: [] };
  }
}

function toTrack(s: any): PlayerTrack {
  return {
    id: s.id,
    title: s.title,
    slug: s.slug,
    artistName: s.artist.name,
    coverImage: s.coverImage,
    audioUrl: s.audioUrl,
    duration: s.duration,
    allowDownload: s.allowDownload,
  };
}

export default async function HomePage() {
  const { featured, trending, latest, genres } = await getHomeData();
  const featuredQueue = featured.map(toTrack);
  const trendingQueue = trending.map(toTrack);
  const latestQueue = latest.map(toTrack);

  return (
    <div className="relative">
      <section className="relative overflow-hidden bg-hero-glow">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20">
          <div className="max-w-2xl">
            <p className="mb-3 text-sm font-medium uppercase tracking-wider text-brand-400">
              Welcome to Seshter 79
            </p>
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
              Stream. Discover.{" "}
              <span className="bg-gradient-to-r from-brand-400 to-accent-purple bg-clip-text text-transparent">
                Download.
              </span>
            </h1>
            <p className="mt-4 text-lg text-surface-400 max-w-lg">
              The modern home for Afrobeats, Hip-Hop, Gospel, Amapiano and more.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/music" className="inline-flex items-center gap-2 rounded-full bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500">
                <Play className="h-4 w-4 fill-current" />
                Browse Music
              </Link>
              <Link href="/genres" className="inline-flex items-center gap-2 rounded-full border border-surface-700 px-6 py-3 text-sm font-semibold hover:bg-surface-800">
                Explore Genres
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl space-y-14 px-4 py-12 sm:px-6">
        <section>
          <div className="mb-6 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-xl font-bold">
              <Sparkles className="h-5 w-5 text-brand-400" />
              Featured Music
            </h2>
            <Link href="/music" className="text-sm text-brand-400 hover:underline">See all</Link>
          </div>
          {featured.length === 0 ? (
            <p className="text-surface-500 text-sm">
              No songs yet. Upload music from the{" "}
              <Link href="/admin/songs/upload" className="text-brand-400 underline">admin panel</Link>.
            </p>
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {featured.map((song) => (
                <SongCard key={song.id} song={song as any} queue={featuredQueue} />
              ))}
            </div>
          )}
        </section>

        <section>
          <div className="mb-6 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-xl font-bold">
              <TrendingUp className="h-5 w-5 text-accent-pink" />
              Trending Now
            </h2>
            <Link href="/music" className="text-sm text-brand-400 hover:underline">See all</Link>
          </div>
          {trending.length === 0 ? (
            <p className="text-surface-500 text-sm">No trending songs yet.</p>
          ) : (
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {trending.map((song, i) => (
                <SongRow key={song.id} song={song as any} index={i} queue={trendingQueue} />
              ))}
            </div>
          )}
        </section>

        {latest.length > 0 && (
          <section>
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-bold">New Releases</h2>
              <Link href="/music" className="text-sm text-brand-400 hover:underline">See all</Link>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {latest.slice(0, 5).map((song) => (
                <SongCard key={song.id} song={song as any} queue={latestQueue} />
              ))}
            </div>
          </section>
        )}

        <section>
          <div className="mb-6 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-xl font-bold">
              <Music2 className="h-5 w-5 text-accent-cyan" />
              Explore Genres
            </h2>
            <Link href="/genres" className="text-sm text-brand-400 hover:underline">All genres</Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {(genres.length
              ? genres
              : [
                  { slug: "afrobeats", name: "Afrobeats" },
                  { slug: "hip-hop", name: "Hip-Hop" },
                  { slug: "gospel", name: "Gospel" },
                  { slug: "amapiano", name: "Amapiano" },
                  { slug: "rnb", name: "R&B" },
                  { slug: "dancehall", name: "Dancehall" },
                ]
            ).map((genre) => (
              <Link
                key={genre.slug}
                href={`/genre/${genre.slug}`}
                className="flex h-24 items-end rounded-xl bg-gradient-to-br from-surface-800 to-surface-900 p-4 font-semibold hover:from-brand-900/40 hover:to-surface-900 transition"
              >
                {genre.name}
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
