"use client";

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Download,
  Repeat,
  Shuffle,
} from "lucide-react";
import { usePlayerStore } from "@/store/playerStore";
import { formatDuration } from "@/lib/utils";
import Link from "next/link";

export function MusicPlayer() {
  const pathname = usePathname();
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const {
    current,
    isPlaying,
    progress,
    volume,
    isMuted,
    repeat,
    shuffle,
    play,
    pause,
    toggle,
    next,
    prev,
    seek,
    setProgress,
    setVolume,
    toggleMute,
    toggleRepeat,
    toggleShuffle,
  } = usePlayerStore();

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !current) return;

    if (audio.src !== current.audioUrl) {
      audio.src = current.audioUrl;
      audio.load();
    }

    if (isPlaying) {
      audio.play().catch(() => pause());
    } else {
      audio.pause();
    }
  }, [current, isPlaying, pause]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = isMuted ? 0 : volume;
  }, [volume, isMuted]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setProgress(audio.currentTime);
    const onEnded = () => {
      if (repeat === "one") {
        audio.currentTime = 0;
        audio.play();
      } else {
        next();
      }
    };

    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("ended", onEnded);
    return () => {
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("ended", onEnded);
    };
  }, [next, repeat, setProgress]);

  useEffect(() => {
    if (!current || !("mediaSession" in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: current.title,
      artist: current.artistName,
      artwork: current.coverImage
        ? [{ src: current.coverImage, sizes: "512x512", type: "image/jpeg" }]
        : [],
    });
    navigator.mediaSession.setActionHandler("play", play);
    navigator.mediaSession.setActionHandler("pause", pause);
    navigator.mediaSession.setActionHandler("previoustrack", prev);
    navigator.mediaSession.setActionHandler("nexttrack", next);
  }, [current, play, pause, prev, next]);

  if (pathname?.startsWith("/admin")) return null;
  if (!current) return null;

  const duration = current.duration || 0;
  const pct = duration > 0 ? (progress / duration) * 100 : 0;

  return (
    <>
      <audio ref={audioRef} preload="metadata" />

      <div className="fixed bottom-14 left-0 right-0 z-40 border-t border-surface-800 bg-surface-900/95 backdrop-blur-xl md:bottom-0">
        <div
          className="h-1 w-full cursor-pointer bg-surface-800"
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const ratio = (e.clientX - rect.left) / rect.width;
            const newTime = ratio * duration;
            if (audioRef.current) audioRef.current.currentTime = newTime;
            seek(newTime);
          }}
        >
          <div className="h-full bg-brand-500 transition-all" style={{ width: `${pct}%` }} />
        </div>

        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-3 sm:px-6 md:h-[72px]">
          <div className="flex min-w-0 flex-1 items-center gap-3">
            <div className="h-12 w-12 shrink-0 overflow-hidden rounded-md bg-surface-800">
              {current.coverImage ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={current.coverImage} alt="" className="h-full w-full object-cover" />
              ) : null}
            </div>
            <div className="min-w-0">
              <Link href={`/song/${current.slug}`} className="block truncate text-sm font-medium hover:underline">
                {current.title}
              </Link>
              <p className="truncate text-xs text-surface-400">{current.artistName}</p>
            </div>
          </div>

          <div className="flex flex-col items-center gap-0.5">
            <div className="flex items-center gap-1 sm:gap-2">
              <button onClick={toggleShuffle} className={`hidden h-8 w-8 items-center justify-center sm:flex ${shuffle ? "text-brand-400" : "text-surface-400 hover:text-white"}`}>
                <Shuffle className="h-4 w-4" />
              </button>
              <button onClick={prev} className="flex h-8 w-8 items-center justify-center text-surface-300 hover:text-white">
                <SkipBack className="h-5 w-5" />
              </button>
              <button onClick={toggle} className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-black hover:scale-105 transition-transform">
                {isPlaying ? <Pause className="h-5 w-5 fill-current" /> : <Play className="h-5 w-5 fill-current ml-0.5" />}
              </button>
              <button onClick={next} className="flex h-8 w-8 items-center justify-center text-surface-300 hover:text-white">
                <SkipForward className="h-5 w-5" />
              </button>
              <button onClick={toggleRepeat} className={`hidden h-8 w-8 items-center justify-center sm:flex ${repeat !== "off" ? "text-brand-400" : "text-surface-400 hover:text-white"}`}>
                <Repeat className="h-4 w-4" />
              </button>
            </div>
            <div className="hidden md:flex w-64 items-center gap-2 text-[10px] text-surface-500">
              <span>{formatDuration(progress)}</span>
              <div className="h-1 flex-1 rounded-full bg-surface-700 overflow-hidden">
                <div className="h-full bg-brand-500" style={{ width: `${pct}%` }} />
              </div>
              <span>{formatDuration(duration)}</span>
            </div>
          </div>

          <div className="hidden sm:flex flex-1 items-center justify-end gap-2">
            {current.allowDownload && (
              <a href={current.audioUrl} download className="flex h-8 w-8 items-center justify-center text-surface-400 hover:text-white" title="Download">
                <Download className="h-4 w-4" />
              </a>
            )}
            <div className="flex items-center gap-2">
              <button onClick={toggleMute} className="text-surface-400 hover:text-white">
                {isMuted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
              <input type="range" min={0} max={1} step={0.01} value={isMuted ? 0 : volume} onChange={(e) => setVolume(parseFloat(e.target.value))} className="w-20 accent-brand-500" />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
