"use client";

import { Play } from "lucide-react";
import { usePlayerStore, type PlayerTrack } from "@/store/playerStore";

export function PlayButton({ track }: { track: PlayerTrack }) {
  const setTrack = usePlayerStore((s) => s.setTrack);

  return (
    <button
      onClick={() => setTrack(track)}
      className="inline-flex items-center gap-2 rounded-full bg-brand-600 px-6 py-3 text-sm font-semibold text-white hover:bg-brand-500"
    >
      <Play className="h-4 w-4 fill-current" />
      Play
    </button>
  );
}
