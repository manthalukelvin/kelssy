"use client";

import Link from "next/link";
import { Play } from "lucide-react";
import { usePlayerStore, type PlayerTrack } from "@/store/playerStore";
import { formatDuration, formatPlayCount } from "@/lib/utils";

type Song = {
  id: string;
  title: string;
  slug: string;
  coverImage: string | null;
  audioUrl: string;
  duration: number;
  playCount: number;
  allowDownload: boolean;
  artist: { name: string };
};

export function SongCard({
  song,
  queue,
}: {
  song: Song;
  queue?: PlayerTrack[];
}) {
  const setTrack = usePlayerStore((s) => s.setTrack);

  function play() {
    const track: PlayerTrack = {
      id: song.id,
      title: song.title,
      slug: song.slug,
      artistName: song.artist.name,
      coverImage: song.coverImage,
      audioUrl: song.audioUrl,
      duration: song.duration,
      allowDownload: song.allowDownload,
    };
    setTrack(track, queue);
  }

  return (
    <div className="group relative overflow-hidden rounded-xl bg-surface-900 p-3 transition hover:bg-surface-800">
      <div className="relative aspect-square overflow-hidden rounded-lg bg-surface-800 mb-3">
        {song.coverImage ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={song.coverImage}
            alt={song.title}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-surface-600 text-3xl font-bold">
            {song.title[0]}
          </div>
        )}
        <button
          onClick={play}
          className="absolute bottom-2 right-2 flex h-10 w-10 items-center justify-center rounded-full bg-brand-500 text-white opacity-0 shadow-lg transition group-hover:opacity-100 hover:scale-105"
          aria-label="Play"
        >
          <Play className="h-5 w-5 fill-current ml-0.5" />
        </button>
      </div>
      <Link href={`/song/${song.slug}`} className="block">
        <p className="truncate font-medium hover:underline">{song.title}</p>
        <p className="truncate text-sm text-surface-400">{song.artist.name}</p>
      </Link>
      <p className="mt-1 text-xs text-surface-500">
        {formatDuration(song.duration)} · {formatPlayCount(song.playCount)} plays
      </p>
    </div>
  );
}

export function SongRow({
  song,
  index,
  queue,
}: {
  song: Song;
  index?: number;
  queue?: PlayerTrack[];
}) {
  const setTrack = usePlayerStore((s) => s.setTrack);

  function play() {
    const track: PlayerTrack = {
      id: song.id,
      title: song.title,
      slug: song.slug,
      artistName: song.artist.name,
      coverImage: song.coverImage,
      audioUrl: song.audioUrl,
      duration: song.duration,
      allowDownload: song.allowDownload,
    };
    setTrack(track, queue);
  }

  return (
    <div className="flex items-center gap-3 rounded-xl bg-surface-900/50 p-3 hover:bg-surface-800/80 transition group">
      {typeof index === "number" && (
        <span className="w-6 text-center text-sm font-bold text-surface-500">
          {index + 1}
        </span>
      )}
      <button
        onClick={play}
        className="relative h-12 w-12 shrink-0 overflow-hidden rounded-md bg-surface-800"
      >
        {song.coverImage ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={song.coverImage} alt="" className="h-full w-full object-cover" />
        ) : null}
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100">
          <Play className="h-5 w-5 fill-white text-white" />
        </div>
      </button>
      <div className="min-w-0 flex-1">
        <Link href={`/song/${song.slug}`} className="block truncate font-medium hover:underline">
          {song.title}
        </Link>
        <p className="truncate text-sm text-surface-400">{song.artist.name}</p>
      </div>
      <span className="text-sm text-surface-500">{formatDuration(song.duration)}</span>
    </div>
  );
}
