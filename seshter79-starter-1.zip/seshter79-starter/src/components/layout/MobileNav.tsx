"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, Library, Download, User } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { href: "/", icon: Home, label: "Home" },
  { href: "/search", icon: Search, label: "Search" },
  { href: "/library", icon: Library, label: "Library" },
  { href: "/downloads", icon: Download, label: "Downloads" },
  { href: "/profile", icon: User, label: "Profile" },
];

export function MobileNav() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-surface-800 bg-surface-950/95 backdrop-blur-xl md:hidden">
      {/* Leave space for the mini player above this nav */}
      <div className="flex h-14 items-center justify-around px-2">
        {items.map((item) => {
          const active =
            item.href === "/"
              ? pathname === "/"
              : pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center gap-0.5 rounded-lg px-3 py-1.5 text-[10px] font-medium transition-colors",
                active ? "text-brand-400" : "text-surface-500"
              )}
            >
              <item.icon className={cn("h-5 w-5", active && "text-brand-400")} />
              {item.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
