"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Search, Menu, User, LogOut, Settings } from "lucide-react";
import { useSession, signOut } from "next-auth/react";
import { cn } from "@/lib/utils";
import { useState } from "react";

const navItems = [
  { href: "/", label: "Home" },
  { href: "/music", label: "Music" },
  { href: "/artists", label: "Artists" },
  { href: "/albums", label: "Albums" },
  { href: "/genres", label: "Genres" },
  { href: "/news", label: "News" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [searchOpen, setSearchOpen] = useState(false);

  // Hide header on admin routes
  if (pathname?.startsWith("/admin")) return null;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-surface-800 bg-surface-950/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-accent-purple font-bold text-white text-sm">
            S79
          </div>
          <span className="hidden sm:block text-lg font-bold tracking-tight">
            Seshter <span className="text-brand-400">79</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                pathname === item.href
                  ? "bg-surface-800 text-white"
                  : "text-surface-400 hover:text-white hover:bg-surface-800/50"
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSearchOpen(true)}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-surface-400 hover:bg-surface-800 hover:text-white transition-colors"
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </button>

          {session ? (
            <div className="relative group">
              <button className="flex h-9 w-9 items-center justify-center rounded-full bg-surface-800 overflow-hidden">
                {session.user?.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={session.user.image}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <User className="h-4 w-4 text-surface-400" />
                )}
              </button>
              <div className="absolute right-0 top-full mt-2 w-48 origin-top-right scale-0 opacity-0 group-hover:scale-100 group-hover:opacity-100 transition-all rounded-xl border border-surface-700 bg-surface-900 p-1 shadow-xl">
                <div className="px-3 py-2 text-xs text-surface-400 border-b border-surface-800 mb-1">
                  {session.user?.email}
                </div>
                <Link
                  href="/library"
                  className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-surface-800"
                >
                  Library
                </Link>
                <Link
                  href="/profile"
                  className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-surface-800"
                >
                  <Settings className="h-4 w-4" /> Profile
                </Link>
                {(session.user as any)?.role !== "USER" && (
                  <Link
                    href="/admin"
                    className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-surface-800 text-brand-400"
                  >
                    Admin Dashboard
                  </Link>
                )}
                <button
                  onClick={() => signOut()}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-surface-800 text-red-400"
                >
                  <LogOut className="h-4 w-4" /> Sign out
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/login"
                className="hidden sm:inline-flex rounded-lg px-3 py-2 text-sm font-medium text-surface-300 hover:text-white"
              >
                Log in
              </Link>
              <Link
                href="/register"
                className="rounded-lg bg-brand-600 px-3 py-2 text-sm font-medium text-white hover:bg-brand-500 transition-colors"
              >
                Sign up
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Simple search overlay placeholder */}
      {searchOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
          onClick={() => setSearchOpen(false)}
        >
          <div
            className="mx-auto mt-20 max-w-xl px-4"
            onClick={(e) => e.stopPropagation()}
          >
            <input
              autoFocus
              type="search"
              placeholder="Search songs, artists, albums..."
              className="w-full rounded-2xl border border-surface-700 bg-surface-900 px-5 py-4 text-lg outline-none focus:border-brand-500"
              onKeyDown={(e) => {
                if (e.key === "Escape") setSearchOpen(false);
                if (e.key === "Enter") {
                  const q = (e.target as HTMLInputElement).value;
                  if (q) window.location.href = `/search?q=${encodeURIComponent(q)}`;
                }
              }}
            />
          </div>
        </div>
      )}
    </header>
  );
}
