"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export function SiteFooter() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;

  return (
    <footer className="border-t border-surface-800 bg-surface-950">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-accent-purple text-xs font-bold text-white">
                S79
              </div>
              <span className="font-bold">
                Seshter <span className="text-brand-400">79</span>
              </span>
            </div>
            <p className="text-sm text-surface-400 max-w-xs">
              Discover, stream and download the music you love. Built for
              listeners worldwide.
            </p>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold text-white">Explore</h4>
            <ul className="space-y-2 text-sm text-surface-400">
              <li>
                <Link href="/music" className="hover:text-white">
                  Music
                </Link>
              </li>
              <li>
                <Link href="/artists" className="hover:text-white">
                  Artists
                </Link>
              </li>
              <li>
                <Link href="/albums" className="hover:text-white">
                  Albums
                </Link>
              </li>
              <li>
                <Link href="/genres" className="hover:text-white">
                  Genres
                </Link>
              </li>
              <li>
                <Link href="/news" className="hover:text-white">
                  News
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold text-white">Account</h4>
            <ul className="space-y-2 text-sm text-surface-400">
              <li>
                <Link href="/library" className="hover:text-white">
                  Your Library
                </Link>
              </li>
              <li>
                <Link href="/playlists" className="hover:text-white">
                  Playlists
                </Link>
              </li>
              <li>
                <Link href="/profile" className="hover:text-white">
                  Profile
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold text-white">Legal</h4>
            <ul className="space-y-2 text-sm text-surface-400">
              <li>
                <Link href="/about" className="hover:text-white">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-white">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-white">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/dmca" className="hover:text-white">
                  Copyright / DMCA
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-surface-800 pt-6 text-center text-xs text-surface-500">
          © {new Date().getFullYear()} Seshter 79. All rights reserved. ·{" "}
          <span className="text-surface-400">music.myjournalplus.com</span>
        </div>
      </div>
    </footer>
  );
}
