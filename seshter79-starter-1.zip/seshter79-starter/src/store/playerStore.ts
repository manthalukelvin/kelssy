"use client";

import { create } from "zustand";

export type PlayerTrack = {
  id: string;
  title: string;
  slug: string;
  artistName: string;
  coverImage: string | null;
  audioUrl: string;
  duration: number;
  allowDownload: boolean;
};

type PlayerState = {
  current: PlayerTrack | null;
  queue: PlayerTrack[];
  isPlaying: boolean;
  progress: number; // seconds
  volume: number;
  isMuted: boolean;
  repeat: "off" | "one" | "all";
  shuffle: boolean;
  setTrack: (track: PlayerTrack, queue?: PlayerTrack[]) => void;
  play: () => void;
  pause: () => void;
  toggle: () => void;
  seek: (seconds: number) => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  next: () => void;
  prev: () => void;
  setProgress: (s: number) => void;
  toggleRepeat: () => void;
  toggleShuffle: () => void;
};

export const usePlayerStore = create<PlayerState>((set, get) => ({
  current: null,
  queue: [],
  isPlaying: false,
  progress: 0,
  volume: 0.85,
  isMuted: false,
  repeat: "off",
  shuffle: false,

  setTrack: (track, queue) =>
    set({
      current: track,
      queue: queue && queue.length ? queue : [track],
      isPlaying: true,
      progress: 0,
    }),

  play: () => set({ isPlaying: true }),
  pause: () => set({ isPlaying: false }),
  toggle: () => set((s) => ({ isPlaying: !s.isPlaying })),

  seek: (seconds) => set({ progress: seconds }),
  setProgress: (s) => set({ progress: s }),
  setVolume: (v) => set({ volume: Math.min(1, Math.max(0, v)), isMuted: false }),
  toggleMute: () => set((s) => ({ isMuted: !s.isMuted })),

  next: () => {
    const { queue, current, shuffle, repeat } = get();
    if (!current || queue.length === 0) return;
    const idx = queue.findIndex((t) => t.id === current.id);
    let nextIdx = idx + 1;
    if (shuffle) {
      nextIdx = Math.floor(Math.random() * queue.length);
    }
    if (nextIdx >= queue.length) {
      if (repeat === "all") nextIdx = 0;
      else {
        set({ isPlaying: false });
        return;
      }
    }
    set({ current: queue[nextIdx], progress: 0, isPlaying: true });
  },

  prev: () => {
    const { queue, current, progress } = get();
    if (!current || queue.length === 0) return;
    if (progress > 3) {
      set({ progress: 0 });
      return;
    }
    const idx = queue.findIndex((t) => t.id === current.id);
    const prevIdx = idx <= 0 ? queue.length - 1 : idx - 1;
    set({ current: queue[prevIdx], progress: 0, isPlaying: true });
  },

  toggleRepeat: () =>
    set((s) => ({
      repeat: s.repeat === "off" ? "all" : s.repeat === "all" ? "one" : "off",
    })),

  toggleShuffle: () => set((s) => ({ shuffle: !s.shuffle })),
}));
